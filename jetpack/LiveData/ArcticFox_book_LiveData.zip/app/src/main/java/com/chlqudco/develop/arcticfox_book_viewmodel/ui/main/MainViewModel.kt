package com.chlqudco.develop.arcticfox_book_viewmodel.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    private val usd_to_eu_rate = 0.74f
    private var dollorText = ""
    //환전 결과 값을 Livedata로 관리할 거임
    private var result : MutableLiveData<Float> = MutableLiveData()

    fun setAmount(value: String){
        this.dollorText = value
        result.value = value.toFloat() * usd_to_eu_rate
    }

    fun getResult(): MutableLiveData<Float>{
        return result
    }
}