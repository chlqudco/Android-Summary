package com.chlqudco.develop.arcticfox_book_viewmodel.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.chlqudco.develop.arcticfox_book_viewmodel.R
import com.chlqudco.develop.arcticfox_book_viewmodel.databinding.FragmentMainBinding

class MainFragment : Fragment() {

    private lateinit var viewModel: MainViewModel

    private lateinit var binding: FragmentMainBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentMainBinding.inflate(inflater,container,false)
        return binding.root
    }

    //초기화 작업을 하는 함수인가?
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        //원래 있던 값 불러오는 역할
        binding.resultText.text = viewModel.getResult().toString()

        //옵져서 인터페이스 안에있는 유일한 함수인 onChanged를 구현
        //LiveData 값이 변경될 때 자동 호출
        val resultObserver = Observer<Float>{
            result -> binding.resultText.text = result.toString()
        }

        //옵저버 등록
        viewModel.getResult().observe(viewLifecycleOwner, resultObserver)

        binding.convertButton.setOnClickListener {
            viewModel.setAmount(binding.dollarText.text.toString())
            //버튼 클릭 할 때 결과값을 불러올 필요가 없어졌음
        }
    }

    companion object {
        fun newInstance() = MainFragment()
    }
}