package com.chlqudco.develop.arcticfox_book_viewmodel.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel

const val RESULT_KEY = "Euro Value"

class MainViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    private val usd_to_eu_rate = 0.74f
    private var dollorText = ""
    //환전 결과 값을 Livedata로 관리할 거임
    private var result : MutableLiveData<Float> = savedStateHandle.getLiveData(RESULT_KEY)

    fun setAmount(value: String){
        //도대체 이건 왜 있는거임
        this.dollorText = value
        val convertedValue = value.toFloat() * usd_to_eu_rate
        result.value = convertedValue
        //값 저장해 놓기
        savedStateHandle.set(RESULT_KEY, convertedValue)
    }

    fun getResult(): MutableLiveData<Float>{
        return result
    }
}