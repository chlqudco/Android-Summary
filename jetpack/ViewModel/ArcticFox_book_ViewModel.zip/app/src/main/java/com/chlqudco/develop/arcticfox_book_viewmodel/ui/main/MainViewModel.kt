package com.chlqudco.develop.arcticfox_book_viewmodel.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    private val usd_to_eu_rate = 0.74f
    private var dollorText = ""
    private var result = 0f

    fun setAmount(value: String){
        this.dollorText = value
        result = value.toFloat() * usd_to_eu_rate
    }

    fun getResult(): Float{
        return result
    }
}