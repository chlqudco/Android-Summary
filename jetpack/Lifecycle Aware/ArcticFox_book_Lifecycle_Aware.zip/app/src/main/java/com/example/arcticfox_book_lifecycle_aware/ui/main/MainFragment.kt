package com.example.arcticfox_book_lifecycle_aware.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.arcticfox_book_lifecycle_aware.DemoObserver
import com.example.arcticfox_book_lifecycle_aware.DemoOwner
import com.example.arcticfox_book_lifecycle_aware.R

class MainFragment : Fragment() {
    private lateinit var viewModel: MainViewModel
    private lateinit var demoOwner: DemoOwner

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        demoOwner = DemoOwner()
        demoOwner.startOwner()
        demoOwner.stopOwner()

        //lifecycle.addObserver(DemoObserver())
    }

    companion object {
        fun newInstance() = MainFragment()
    }
}