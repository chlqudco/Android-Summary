package com.chlqudco.develop.arcticfox_book_viewmodel.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.chlqudco.develop.arcticfox_book_viewmodel.R
import com.chlqudco.develop.arcticfox_book_viewmodel.databinding.FragmentMainBinding
import com.chlqudco.develop.arcticfox_book_viewmodel.BR.myViewModel

class MainFragment : Fragment() {

    private lateinit var viewModel: MainViewModel

    lateinit var binding: FragmentMainBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false)
        //바인딩 객체의 생명주기 소유자를 프래그먼트로 지정하여 프래그먼트가 소멸될 때 같이 소멸되도록 함
        binding.lifecycleOwner = this
        return binding.root
    }

    //초기화 작업을 하는 함수인가?
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        //실제 mainViewModel 객체와 연결
        //MainViewModel의 참조를 여기서 얻으므로 여기서 지정한거임
        binding.setVariable(myViewModel, viewModel)
    }

    companion object {
        fun newInstance() = MainFragment()
    }
}