package com.chlqudco.develop.arcticfox_book_fragment

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import com.chlqudco.develop.arcticfox_book_fragment.databinding.FragmentToolbarBinding
import java.lang.ClassCastException

class ToolbarFragment : Fragment(), SeekBar.OnSeekBarChangeListener {

    private lateinit var binding: FragmentToolbarBinding

    var seekValue = 10

    var activityCallback: ToolbarFragment.ToolbarListener? = null

    //나 리스너 정의할래..
    interface ToolbarListener{
        fun onButtonClick(position: Int, text: String)
    }

    //액티비티와 손잡을 수 있는 유일한 공간
    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            activityCallback = context as ToolbarListener
        } catch (e: ClassCastException){
            throw ClassCastException(context.toString())
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentToolbarBinding.inflate(inflater, container, false)
        return binding.root
    }

    //onCreateView에서 안하고 여기서하는 이유가 뭘까?
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.seekBar1.setOnSeekBarChangeListener(this)
        binding.button1.setOnClickListener {
            buttonClicked(it)
        }
    }

    //액티비티야 내가 값을 줄게!
    private fun buttonClicked(view: View) {
        activityCallback?.onButtonClick(seekValue, binding.editText1.text.toString())
    }

    override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
        seekValue = p1
    }

    override fun onStartTrackingTouch(p0: SeekBar?) {}

    override fun onStopTrackingTouch(p0: SeekBar?) {}

}