package com.chlqudco.develop.arcticfox_book_videoplayer

import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.widget.MediaController
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.widget.Toast
import com.chlqudco.develop.arcticfox_book_videoplayer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    private var mediaController : MediaController ?= null
    private var receiver: BroadcastReceiver ?= null

    private val REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        configureVideoView()
    }

    private fun configureVideoView() {
        binding.videoView1.setVideoURI(Uri.parse("android.resource://$packageName/raw/movie"))

        mediaController = MediaController(this)
        mediaController?.setAnchorView(binding.videoView1)
        binding.videoView1.setMediaController(mediaController)

        binding.videoView1.setOnPreparedListener { mp ->
            mp.isLooping = true
        }

        binding.videoView1.start()
    }

    fun enterPipMode(view: View) {
        //가로세로비율 설정
        val rational = Rational(binding.videoView1.width, binding.videoView1.height)
        //pip 인스턴스 생성
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(rational)
            .build()

        //버튼 없애기
        binding.pipButton.visibility = View.INVISIBLE
        //컨트롤러 없애기
        binding.videoView1.setMediaController(null)
        //pip시작
        enterPictureInPictureMode(params)
    }

    //모드 변경 감지
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration?) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)

        //pip 모드인 경우
        if (isInPictureInPictureMode){
            //브로드캐스트랑 펜딩인텐트 이용해서 토스트 띄우기
            val filter = IntentFilter()
            filter.addAction("com.chlqudco.develop.arcticfox_book_videoplayer")

            //뭔가 받으면 토스트
            receiver = object  : BroadcastReceiver(){
                override fun onReceive(p0: Context?, p1: Intent?) {
                    Toast.makeText(this@MainActivity,"영화",Toast.LENGTH_SHORT).show()
                }
            }
            registerReceiver(receiver, filter)
            createPipAction()
        }else{
            binding.pipButton.visibility = View.VISIBLE
            binding.videoView1.setMediaController(mediaController)

            receiver?.let {
                unregisterReceiver(it)
            }
        }
    }

    private fun createPipAction(){
        val actions = ArrayList<RemoteAction>()

        val actionIntent = Intent("com.chlqudco.develop.arcticfox_book_videoplayer")
        val pendingIntent = PendingIntent.getBroadcast(this, REQUEST_CODE, actionIntent, PendingIntent.FLAG_IMMUTABLE)

        val icon = Icon.createWithResource(this,R.drawable.ic_android_black_24dp)
        val remoteAction = RemoteAction(icon, "정보", "비디오 정보", pendingIntent)
        actions.add(remoteAction)

        val params = PictureInPictureParams.Builder()
            .setActions(actions)
            .build()

        setPictureInPictureParams(params)
    }
}