package com.chlqudco.develop.arcticfox_book_directreply

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Icon
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.chlqudco.develop.arcticfox_book_directreply.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var notificationManager: NotificationManager?=null
    private val channelID = "ChannelID"
    private val notificationId = 101
    private val KEY_TEXT_REPLY = "KEY_TEXT_REPLY"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        createNotificationChannel(channelID, "채널 이름", "채널 설명")

        handleIntent()
    }

    private fun createNotificationChannel(id: String, name: String, description: String) {
        val importance = NotificationManager.IMPORTANCE_HIGH
        val channel = NotificationChannel(id, name, importance)

        channel.apply {
            this.description = description
            enableLights(true)
            lightColor = Color.RED
            enableVibration(true)
            vibrationPattern = longArrayOf(100,200,300,400,500,400,300,200,400)
        }

        notificationManager?.createNotificationChannel(channel)
    }

    fun sendNotification(view: View) {
        val replyLabel = "여기에 입력해 주세요"
        val remoteInput = RemoteInput.Builder(KEY_TEXT_REPLY)
            .setLabel(replyLabel)
            .build()

        val resultIntent = Intent(this,MainActivity::class.java)
        val resultPendingIntent = PendingIntent.getActivity(this,0,resultIntent,PendingIntent.FLAG_MUTABLE)

        val icon = Icon.createWithResource(this,android.R.drawable.ic_dialog_info)
        val replyAction = Notification.Action.Builder(icon,"응답",resultPendingIntent)
            .addRemoteInput(remoteInput)
            .build()

        val newMessageNotification = Notification.Builder(this, channelID)
            .setColor(ContextCompat.getColor(this, com.google.android.material.R.color.design_default_color_primary))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("알림 제목 입니다")
            .setContentText("알람 상세 내용 입니다")
            .addAction(replyAction).build()

        notificationManager?.notify(notificationId, newMessageNotification)
    }

    private fun handleIntent(){
        val intent = this.intent
        val remoteInput = RemoteInput.getResultsFromIntent(intent)
        if (remoteInput != null){
            val inputString = remoteInput.getCharSequence(KEY_TEXT_REPLY).toString()
            binding.textView.text = inputString
        }
    }
}