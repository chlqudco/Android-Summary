package com.chlqudco.develop.arcticfox_book_notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Icon
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {

    private var notificationManager: NotificationManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //매니저 초기화 후
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        //채널 생성
        createNotificationChannel("channelID", "채널이름", "채널설명")

    }

    private fun createNotificationChannel(id: String, name: String, description: String){
        //알림 중요도
        val importance = NotificationManager.IMPORTANCE_LOW
        //채널 초기화
        val channel = NotificationChannel(id, name, importance)

        //채널에 더 많은 설정하기, 옵션임, 더 많은건 문서봐라
        channel.apply {
            this.description = description
            this.enableLights(true)
            this.lightColor = Color.RED
            this.enableVibration(true)
            this.vibrationPattern = longArrayOf(100,200,300,400,500,400,300,200,400)
        }

        //채널 생성
        notificationManager?.createNotificationChannel(channel)
    }

    fun sendNotification(view: View) {

        val notificationID = 101
        val resultIntent = Intent(this,ResultActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this,0, resultIntent,PendingIntent.FLAG_IMMUTABLE)

        val channelID = "channelID"

        val icon: Icon = Icon.createWithResource(this,android.R.drawable.ic_dialog_info)

        //액션 지정
        val action: Notification.Action = Notification.Action.Builder(icon,"Open", pendingIntent).build()

        //더 많은 옵션은 마찬가지로 문서봐라
        val notification = Notification.Builder(this,channelID)
            .setContentTitle("알림 제목 입니다.")
            .setContentText("알림 상세 내용 입니다.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setChannelId(channelID)
            .setNumber(99)
            .setActions(action)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager?.notify(notificationID, notification)
    }
}