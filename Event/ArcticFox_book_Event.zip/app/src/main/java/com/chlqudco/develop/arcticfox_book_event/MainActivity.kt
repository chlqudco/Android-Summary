package com.chlqudco.develop.arcticfox_book_event

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.chlqudco.develop.arcticfox_book_event.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.myButton.setOnClickListener {
            binding.statusText.text = "Button Clicked"
        }

        /*
        binding.myButton.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                TODO("Not yet implemented")
            }

        })

         */

        binding.myButton.setOnLongClickListener {
            binding.statusText.text = "Long Clicked"
            true
        }

        binding.myLayout.setOnTouchListener { view, motionEvent ->
            //필요한 작업
            true
        }
    }
}