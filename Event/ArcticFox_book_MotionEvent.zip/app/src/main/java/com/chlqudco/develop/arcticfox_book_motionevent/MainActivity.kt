package com.chlqudco.develop.arcticfox_book_motionevent

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import com.chlqudco.develop.arcticfox_book_motionevent.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.activityMain.setOnTouchListener { view, motionEvent ->
            handleTouch(motionEvent)
            true
        }

    }

    private fun handleTouch(m: MotionEvent) {
        //몇개의 클릭이 일어났는지 체크 후 반복문 돌리기
        val pointerCount = m.pointerCount

        for (i in 0 until pointerCount){
            //좌표값과 id등 정보를 갖고
            val x = m.getX(i)
            val y = m.getY(i)
            val id = m.getPointerId(i)
            val action = m.actionMasked
            val actionIndex = m.actionIndex
            val actionString: String

            //어떤 액션이 일어나는지 조사
            when(action){
                MotionEvent.ACTION_DOWN -> actionString = "DOWN"
                MotionEvent.ACTION_UP -> actionString = "DOWN"
                MotionEvent.ACTION_POINTER_DOWN -> actionString = "DOWN"
                MotionEvent.ACTION_POINTER_UP -> actionString = "DOWN"
                MotionEvent.ACTION_MOVE -> actionString = "DOWN"
                else -> actionString = ""
            }
            val touchStatus = "Action: $actionString Index: $actionIndex ID: $id X: $x Y: $y"
            if (id==0){
                binding.textView1.text = touchStatus
            } else{
                binding.textView2.text = touchStatus
            }
        }
    }
}