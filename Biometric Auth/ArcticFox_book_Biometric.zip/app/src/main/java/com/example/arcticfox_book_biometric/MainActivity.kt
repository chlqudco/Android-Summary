package com.example.arcticfox_book_biometric

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricPrompt
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CancellationSignal
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private val authenticationCallback: BiometricPrompt.AuthenticationCallback
        get() = object : BiometricPrompt.AuthenticationCallback(){

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                notifyUser("에러 발생 : $errString")
                super.onAuthenticationError(errorCode, errString)
            }

            override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
                super.onAuthenticationHelp(helpCode, helpString)
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
            }

            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                notifyUser("인증에 성공했습니다")
                super.onAuthenticationSucceeded(result)
            }

        }

    private var cancellationSignal: CancellationSignal? = null

    private fun getCancellationSignal(): CancellationSignal{
        cancellationSignal = CancellationSignal()
        cancellationSignal?.setOnCancelListener {
            notifyUser("취소됐습니다.")
        }
        return cancellationSignal as CancellationSignal
    }

    fun authenticateUser(view: View){
        val biometricPrompt = BiometricPrompt.Builder(this)
            .setTitle("생체 인증")
            .setSubtitle("계속 하려면 인증해주세요")
            .setDescription("이 앱은 생체인증이 필요합니다")
            .setNegativeButton("취소", this.mainExecutor, DialogInterface.OnClickListener { dialog, which ->
                notifyUser("인증을 취소했습니다")
            }).build()

        //mainExecutor는 메인쓰레드를 말하는 거임
        biometricPrompt.authenticate(getCancellationSignal(), mainExecutor, authenticationCallback)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkBiometricSupport()
    }

    private fun checkBiometricSupport(): Boolean {
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

        //잠금 화면을 안한 경우
        if (!keyguardManager.isKeyguardSecure){
            notifyUser("잠금 설정이 되어 있지 않습니다")
            return false
        }

        //권한이 없는경우
        if (ActivityCompat.checkSelfPermission(this,Manifest.permission.USE_BIOMETRIC) != PackageManager.PERMISSION_GRANTED){
            notifyUser("지문 인식 권한이 없습니다")
        }

        return packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
    }

    //토스트 띄우는 함수
    private fun notifyUser(msg: String){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}