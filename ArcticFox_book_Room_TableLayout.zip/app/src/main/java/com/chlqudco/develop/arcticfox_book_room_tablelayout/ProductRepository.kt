package com.chlqudco.develop.arcticfox_book_room_tablelayout

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.*

//뷰모델을 대신하여 Room DB와 상호작용하는 책임을 갖고 있다
class ProductRepository(application: Application) {
    val searchResults = MutableLiveData<List<ProductEntity>>()

    private var productDao: ProductDao
    val allProducts: LiveData<List<ProductEntity>>

    init {
        val db: ProductRoomDatabase = ProductRoomDatabase.getDatabase(application)
        productDao = db.productDao()
        allProducts = productDao.getAllProducts()
    }

    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    fun insertProduct(newProduct: ProductEntity){
        coroutineScope.launch(Dispatchers.IO) {
            asyncInsert(newProduct)
        }
    }

    private suspend fun asyncInsert(product: ProductEntity) {
        productDao.insertProduct(product)
    }

    fun deleteProduct(name: String){
        coroutineScope.launch(Dispatchers.IO) {
            asyncDelete(name)
        }
    }

    private suspend fun asyncDelete(name: String) {
        productDao.deleteProduct(name)
    }

    fun findProduct(name: String){
        coroutineScope.launch(Dispatchers.Main){
            searchResults.value = asyncFind(name).await()
        }
    }

    private suspend fun asyncFind(name: String): Deferred<List<ProductEntity>> {
        return coroutineScope.async(Dispatchers.IO){
            return@async productDao.findProduct(name)
        }
    }

}