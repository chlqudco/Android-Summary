package com.chlqudco.develop.arcticfox_book_room_tablelayout.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.chlqudco.develop.arcticfox_book_room_tablelayout.ProductEntity
import com.chlqudco.develop.arcticfox_book_room_tablelayout.ProductRepository

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProductRepository = ProductRepository(application)
    private val allProducts: LiveData<List<ProductEntity>>
    private val searchResults: MutableLiveData<List<ProductEntity>>

    init {
        allProducts = repository.allProducts
        searchResults = repository.searchResults
    }

    fun insertProduct(productEntity: ProductEntity){
        repository.insertProduct(productEntity)
    }

    fun findProduct(name: String){
        repository.findProduct(name)
    }

    fun deleteProduct(name: String){
        repository.deleteProduct(name)
    }

    fun getSearchResults(): MutableLiveData<List<ProductEntity>>{
        return searchResults
    }

    fun getAllProducts(): LiveData<List<ProductEntity>>{
        return allProducts
    }
}