package com.chlqudco.develop.arcticfox_book_room_tablelayout

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ProductDao {

    @Insert
    fun insertProduct(productEntity: ProductEntity)

    @Query("SELECT * FROM products WHERE productName = :name")
    fun findProduct(name: String): List<ProductEntity>

    @Query("DELETE FROM products WHERE productName = :name" )
    fun deleteProduct(name: String)

    @Query("SELECT * FROM products")
    fun getAllProducts(): LiveData<List<ProductEntity>>
}