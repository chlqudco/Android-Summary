package com.dongchyeon.simplechatapp.data.model

data class Room(
    val userName: String,
    val roomName: String
)